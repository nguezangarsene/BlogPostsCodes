package com.wix.nguezang.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author Nguezang Arsene
 */
@Controller
public class HomeController {

    @GetMapping(value = {"", "/springsec"})
    public String index() {
        return "home/home";
    }

    @GetMapping(value = {"/springsec/home"})
    public String home() {
        return "home/home";
    }


}
